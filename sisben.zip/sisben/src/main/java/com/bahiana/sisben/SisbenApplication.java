package com.bahiana.sisben;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SisbenApplication {

	public static void main(String[] args) {
		SpringApplication.run(SisbenApplication.class, args);
	}

}
